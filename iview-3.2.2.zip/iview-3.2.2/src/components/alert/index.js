import Alert from './alert.vue';
export default Alert;