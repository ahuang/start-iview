import Checkbox from './checkbox.vue';
import CheckboxGroup from './checkbox-group.vue';

Checkbox.Group = CheckboxGroup;
export default Checkbox;