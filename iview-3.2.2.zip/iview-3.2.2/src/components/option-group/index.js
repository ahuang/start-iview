import OptionGroup from '../select/option-group.vue';

export default OptionGroup;