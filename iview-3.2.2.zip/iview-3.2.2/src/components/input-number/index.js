import InputNumber from './input-number.vue';
export default InputNumber;