import Icon from './icon.vue';
export default Icon;