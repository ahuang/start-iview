import Transfer from './transfer.vue';
export default Transfer;